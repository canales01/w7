About Flash plugin, put here:
- pepflashplayer.dll